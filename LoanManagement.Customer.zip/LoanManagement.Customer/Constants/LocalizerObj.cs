﻿namespace LoanManagement.Customer.Constants;

public class LocalizerObj
{
    public string SharedResource { get; set; }
}
