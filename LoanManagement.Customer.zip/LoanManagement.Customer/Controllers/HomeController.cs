﻿using LoanManagement.Customer.Resources;

namespace LoanManagement.Customer.Controllers;

/// <summary>
/// 
/// </summary>
[Route("")]
public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IConfiguration _config;
    private readonly IMemoryCache _memoryCache;
    private readonly HttpClient Client = new HttpClient();
    /// <summary>
    /// 
    /// </summary>
    /// <param name="logger"></param>
    /// <param name="config"></param>
    /// <param name="memoryCache"></param>
    public HomeController(ILogger<HomeController> logger,
        IConfiguration config,
        IMemoryCache memoryCache)
    {
        _logger = logger;
        _config = config;
        _memoryCache = memoryCache;
    }

    private string URL => MyConstants.LoanManagementApiUrl;

    public IActionResult Index()
    {
        if (string.IsNullOrEmpty(HttpContext.Session.GetString("_SESSIONID")))
            return RedirectToAction("Login", "Compte");

        return View();
    }

    [Route("Azerty")]
    public IActionResult Azerty()
    {
        return View();
    }

    [Route("Querty")]
    public IActionResult Querty()
    {
        return View();
    }

    [Route("MesDemandes")]
    public IActionResult MesDemandes()
    {
        if (string.IsNullOrEmpty(HttpContext.Session.GetString("_SESSIONID")))
            return RedirectToAction("Login", "Compte");

        return View();
    }

    [Route("Credit")]
    public IActionResult Credit()
    {
        if (string.IsNullOrEmpty(HttpContext.Session.GetString("_SESSIONID")))
            return RedirectToAction("Login", "Compte");

        return View();
    }

    [HttpGet]
    [Route("Logout")]
    public async Task<IActionResult> Logout()
    {
        HttpContext.Session.Remove("_SESSIONID");
        return RedirectToAction("Login", "Compte");
    }

    [HttpPost]
    [Route("Login")]
    public async Task<IActionResult> Login(ClientLoginViewModel resource)
    {
        if (!ModelState.IsValid)
            return new JsonResult(new
            { }, ConfigConstant.JsonSettings())
            {
                StatusCode = (int)HttpStatusCode.BadRequest
            };
        try
        {
            var loginResource = new ClientLoginResource()
            {
                Indice = resource.ClientLoginResource.Indice,
                Telephone = resource.ClientLoginResource.Telephone
            };
            var content = new StringContent(JsonConvert.SerializeObject(loginResource), Encoding.UTF8, "application/json");
            var result = await Client.PostAsync(URL + "/Client/login", content);
            if (result.IsSuccessStatusCode)
            {
                var response = await result.Content.ReadFromJsonAsync<ClientResource>();
                HttpContext.Session.SetString("_SESSIONID", response.Id.ToString());
                TempData["User"] = $"{response.Nom} {response.Prenoms}";
                return new JsonResult(new
                {
                    title = "Connexion",
                    typeMessage = TypeMessage.Success.GetString(),
                    message = "Connexion effectuée avec succès",
                    description = string.Empty,
                    timeOut = 8000,
                    strJsonLogin = JsonConvert.SerializeObject(JsonConvert.DeserializeObject<ClientResource>(
                       await result.Content.ReadAsStringAsync(), ConfigConstant.SetDateTimeConverter()))
                }, ConfigConstant.JsonSettings())
                {
                    StatusCode = (int)HttpStatusCode.OK
                };

            }
            var jQueryViewModel = await AppConstant.GetResponseMessage(result);
            return new JsonResult(new
            {
                title = "Connexion",
                typeMessage = TypeMessage.Error.GetString(),
                message = "Identifiants incorrects",
                description = "Vos identifiants sont incorrects",
                strJsonLogin = JsonConvert.SerializeObject(jQueryViewModel),
                timeOut = jQueryViewModel.TimeOut

            });
        }

        catch (Exception e)
        {

            return new JsonResult(new
            {
                title = "Erreur",
                typeMessage = TypeMessage.Error.GetString(),
                message = e.Message,
                description = e.Message,
                timeOut = 8000
            }, ConfigConstant.JsonSettings())
            {
                StatusCode = (int)HttpStatusCode.InternalServerError
            };
        }
    }

    [HttpPost]
    [Route("DemandeCredit")]
    public async Task<IActionResult> DemandeCredit(SaveDossierClientResourceViewModel model)
    {
        if (ModelState.HasReachedMaxErrors)
            return new JsonResult(new
            { }, ConfigConstant.JsonSettings())
            {
                StatusCode = (int)HttpStatusCode.BadRequest
            };
        try
        {
            var contentData = new MultipartFormDataContent();
            
            //Data(contentData, model.ContratTravail, "ContratTravail");
            //Data(contentData, model.AttestationTravail, "AttestationTravail");
            //Data(contentData, model.PremierBulletinSalaire, "PremierBulletinSalaire");
            //Data(contentData, model.DeuxiemeBulletinSalaire, "DeuxiemeBulletinSalaire");
            //Data(contentData, model.TroisiemeBulletinSalaire, "TroisiemeBulletinSalaire");
            //Data(contentData, model.FactureProFormat, "FactureProFormat");
            //Data(contentData, model.CarteIdentite, "CarteIdentite");


            contentData.Add(new StringContent(model.SaveDossierClientResource.Taille.ToString()), "Taille");
            contentData.Add(new StringContent(model.SaveDossierClientResource.Poids.ToString()), "Poids");
            contentData.Add(new StringContent(model.SaveDossierClientResource.TensionArterielle.ToString()), "TensionArterielle");
            contentData.Add(new StringContent(model.SaveDossierClientResource.Fumeur.ToString()), "Fumeur");
            contentData.Add(new StringContent(model.SaveDossierClientResource.NbrCigarettes.ToString()), "NbrCigarettes");
            contentData.Add(new StringContent(model.SaveDossierClientResource.Buveur.ToString()), "Buveur");
            contentData.Add(new StringContent(model.SaveDossierClientResource.Distractions.ToString()), "Distractions");
            contentData.Add(new StringContent(model.SaveDossierClientResource.EcheanceCarteIdentite.ToString()), "EcheanceCarteIdentite");
            contentData.Add(new StringContent(model.SaveDossierClientResource.EstSportif.ToString()), "EstSportif");
            contentData.Add(new StringContent(model.SaveDossierClientResource.CategorieSport.ToString()), "CategorieSport");
            contentData.Add(new StringContent(model.SaveDossierClientResource.EstInfirme.ToString()), "EstInfirme");
            contentData.Add(new StringContent(model.SaveDossierClientResource.NatureInfirmite.ToString()), "NatureInfirmite");
            contentData.Add(new StringContent(model.SaveDossierClientResource.DateSurvenance.ToString()), "DateSurvenance");
            contentData.Add(new StringContent(model.SaveDossierClientResource.StatutMaritalId.ToString()), "StatutMaritalId");
            contentData.Add(new StringContent(model.SaveDossierClientResource.ClientId.ToString()), "ClientId");
            //var content = new StringContent(JsonConvert.SerializeObject(dossierClient), Encoding.UTF8, "application/json");
            Client.Timeout = TimeSpan.FromMilliseconds(Timeout.Infinite);
            var result = await Client.PostAsync(URL + "/DossierClient/add", contentData);

            if (result.IsSuccessStatusCode)
            {
                var response = await result.Content.ReadFromJsonAsync<DossierClientResource>();
                TempData["Credit"] = response.Id;
                return new JsonResult(new
                {
                    title = "Demande de crédit",
                    typeMessage = TypeMessage.Success.GetString(),
                    message = "Demande de crédit effectuée avec succès",
                    description = string.Empty,
                    timeOut = 8000,
                    strJsonDemandeCredit = JsonConvert.SerializeObject(JsonConvert.DeserializeObject<ClientResource>(
                       await result.Content.ReadAsStringAsync(), ConfigConstant.SetDateTimeConverter()))
                }, ConfigConstant.JsonSettings())
                {
                    StatusCode = (int)HttpStatusCode.OK
                };
            }
            var jQueryViewModel = await AppConstant.GetResponseMessage(result);
            return new JsonResult(new
            {
                title = "Demande de crédit",
                typeMessage = TypeMessage.Error.GetString(),
                message = "Une erreur est survenue",
                description = "Vos informations sont incorrectes, réessayez à nouveau",
                strJsonDemandeCredit = JsonConvert.SerializeObject(jQueryViewModel),
                timeOut = jQueryViewModel.TimeOut

            });
        }
        catch (Exception ex)
        {
            return new JsonResult(new
            {
                title = "Erreur",
                typeMessage = TypeMessage.Error.GetString(),
                message = ex.Message,
                description = ex.Message,
                timeOut = 8000
            }, ConfigConstant.JsonSettings())
            {
                StatusCode = (int)HttpStatusCode.InternalServerError
            };
        }
    }

    [Route("erreur")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        ViewBag.Title = "Erreur";

        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }


    [Route("page-bientôt-disponible")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult ComingSoon()
    {
        ViewBag.Title = "Bientôt disponible";

        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    [Route("page-non-disponible")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult PageNotAvailable()
    {
        ViewBag.Title = "Bientôt disponible";

        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }


    [Route("page-non-autorisée")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult NotAuthorized()
    {
        ViewBag.Title = "Page non autorisée";

        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }


    [Route("page-en-maintenance")]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult UnderMaintenance()
    {
        ViewBag.Title = "Maintenance";

        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    public static MultipartFormDataContent Data(MultipartFormDataContent content, IFormFile file, string field)
    {
        byte[] data;
        using (var br = new BinaryReader(file.OpenReadStream()))
        {
            data = br.ReadBytes((int)file.OpenReadStream().Length);
        }
        var bytes = new ByteArrayContent(data);
        content.Add(bytes, field, file.FileName);

        return content;
    }

    public static byte[]? Data(IFormFile file)
    {
        if(file is not null)
        {
            byte[] data;
            using (var br = new BinaryReader(file.OpenReadStream()))
            {
                data = br.ReadBytes((int)file.OpenReadStream().Length);
            }

            return data;
        }

        return null;
    }
}
