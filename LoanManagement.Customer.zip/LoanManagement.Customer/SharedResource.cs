﻿namespace LoanManagement.Customer;

public class SharedResource
{ }
