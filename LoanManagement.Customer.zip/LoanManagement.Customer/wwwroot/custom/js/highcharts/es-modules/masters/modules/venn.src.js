/**
 * @license Highcharts JS v10.0.0 (2022-03-07)
 * @module highcharts/modules/venn
 * @requires highcharts
 *
 * (c) 2017-2021 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Venn/VennSeries.js';
